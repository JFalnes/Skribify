import asyncio
import logging
from pathlib import Path
import shutil
from pydub import AudioSegment
from openai import OpenAI
import json
import datetime
import os
from contextlib import contextmanager
from tempfile import TemporaryDirectory

try:
    from .config import setup as config_setup
except ImportError:
    from config import setup as config_setup

# Setup configuration and logging
config_setup()
client = OpenAI()
__version__ = '0.2'
logging.basicConfig(filename='logs/log.log',
                    filemode='a',
                    format='%(asctime)s,%(msecs)d %(name)s %(levelname)s %(message)s',
                    datefmt='%H:%M:%S',
                    level=logging.INFO)

# Constants and configuration
DEFAULT_PROMPT = 'Summarize the following video in two sentences:'
CHUNK_DURATION_MS = 2 * 60 * 1000  # 2 minutes
TEMP_CHUNKS_DIR = "chunks"
TRANSCRIPTION_MODEL = 'whisper-1'
SUMMARIZATION_MODEL = 'gpt-4-1106-preview'

# Load system prompt from file
with open(Path('Skribify/prompt.txt'), 'r') as prompt_file:
    SYSTEM_PROMPT = prompt_file.read().strip()

class Transcriber:
    def __init__(self, file_path):
        self.file_path = file_path

    def split_by_duration(self, audio_segment):
        """Split audio into chunks of specified duration."""
        chunks = []
        while len(audio_segment) > CHUNK_DURATION_MS:
            chunks.append(audio_segment[:CHUNK_DURATION_MS])
            audio_segment = audio_segment[CHUNK_DURATION_MS:]
        chunks.append(audio_segment)
        return chunks

    async def transcribe_chunk(self, chunk, chunk_index, loop):
        """Asynchronously transcribe a single chunk."""
        with TemporaryDirectory() as temp_dir:
            chunk_file = Path(temp_dir) / f'chunk{chunk_index}.mp3'
            chunk.export(chunk_file.as_posix(), format="mp3")

            with open(chunk_file, 'rb') as audio_file:
                transcript_obj = await loop.run_in_executor(None, lambda: client.audio.transcriptions.create(model=TRANSCRIPTION_MODEL, file=audio_file))
            return transcript_obj.text

    async def transcribe(self):
        """Transcribe the given audio file into text."""
        loop = asyncio.get_event_loop()
        audio = AudioSegment.from_file(self.file_path)

        chunks = self.split_by_duration(audio)
        transcribe_tasks = [self.transcribe_chunk(chunk, i, loop) for i, chunk in enumerate(chunks)]
        transcripts = await asyncio.gather(*transcribe_tasks)
        return ' '.join(transcripts).strip()

class Summarizer:
    def __init__(self, transcript, prompt, system):
        self.transcript = transcript + "\nUser Instructions: "
        self.prompt = prompt
        self.system = system

    async def summarize(self):
        """Use OpenAI API to summarize the transcript."""
        try:
            loop = asyncio.get_event_loop()
            completion = await loop.run_in_executor(None, lambda: client.chat.completions.create(
                model=SUMMARIZATION_MODEL,
                messages=[
                    {"role": "system", "content": self.system},
                    {'role': 'user', 'content': self.transcript},
                    {'role': 'user', 'content': self.prompt}
                ]
            ))
            return completion
        except Exception as e:
            logging.error(f'\nError during summarization: {e}\n')
            return None

class Skribify:
    def __init__(self, callback, prompt=DEFAULT_PROMPT, system=SYSTEM_PROMPT, file_entry=None, transcribe_only=False):
        self.file_entry = file_entry
        self.prompt = prompt
        self.system = system
        self.callback = callback
        self.transcribe_only = transcribe_only
        self.loop = asyncio.get_event_loop()
        self.data_dict = {}

    async def transcribe_and_summarize(self):
        transcriber = Transcriber(self.file_entry)
        transcript = await transcriber.transcribe()

        if transcript:
            self.data_dict['file'] = self.file_entry
            self.data_dict['transcript'] = transcript
            self.write_to_json('transcript')

            if not self.transcribe_only:
                summarizer = Summarizer(transcript, self.prompt, self.system)
                summary = await summarizer.summarize()
                if summary:
                    self.data_dict['summary'] = summary.choices[0].message.content
                    self.write_to_json('summary')
                    self.callback(summary.choices[0].message.content)

    def write_to_json(self, data_type):
        """Write transcription or summary data to a JSON file."""
        now_str = datetime.datetime.now().strftime('%Y-%m-%d_%H-%M-%S')
        directory = Path('output')
        directory.mkdir(parents=True, exist_ok=True)
        json_file = directory / f'{self.file_entry.stem}_{data_type}_{now_str}.json'

        with open(json_file, 'w') as f:
            json.dump(self.data_dict, f, indent=4)

    def run(self):
        """Run the transcription and summarization process."""
        logging.info(f'Starting Skribify')
        if self.file_entry:
            self.loop.run_until_complete(self.transcribe_and_summarize())
        else:
            logging.error('\nError: Please provide a valid file path.\n')

if __name__ == '__main__':
    # Example usage or testing code
    pass
